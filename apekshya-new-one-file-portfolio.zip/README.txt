APEKSHYA PORTFOLIO — ONE FILE

1. Double-click index.html to view in your browser.
2. In GitHub, open your repository and upload ONLY index.html to the top (root) level, replacing any old index.html.
3. Commit changes, then check Settings > Pages.
4. Hard-refresh the published site (Ctrl+Shift+R).

No assets folder or separate CSS/JS files are required. The photographs are embedded in index.html.
All photographs are illustrative AI-generated visuals, not real project photographs.
